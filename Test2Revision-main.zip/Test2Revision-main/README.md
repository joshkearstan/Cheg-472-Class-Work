# Test2Revision
Test 2 Code
Here is my code for test 2, it looks to analyze data using filtering techniques learned in class and then basic predicitive modelling to help analyze the data.
